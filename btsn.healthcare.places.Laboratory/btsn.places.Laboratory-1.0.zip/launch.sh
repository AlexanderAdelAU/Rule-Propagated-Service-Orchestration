#!/bin/bash

echo "Starting Laboratory Service..."
echo ""
if [ $# -eq 0 ]; then
    echo "Usage: ./launch.sh -version <version> [-service <serviceName>]"
    echo "Example: ./launch.sh -version v001"
    echo "         ./launch.sh -version v001 -service LaboratoryService"
    exit 1
fi
cd laboratory
java -cp "btsn.places.Laboratory.jar:lib/*" org.btsn.handlers.ServiceLoader "$@"
cd ..
if [ $? -ne 0 ]; then
    echo ""
    echo "Application exited with an error."
fi
		