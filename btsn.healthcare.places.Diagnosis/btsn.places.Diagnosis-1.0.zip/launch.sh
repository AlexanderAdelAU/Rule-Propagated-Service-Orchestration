#!/bin/bash

echo "Starting Diagnosis Service..."
echo ""
if [ $# -eq 0 ]; then
    echo "Usage: ./launch.sh -version <version> [-service <serviceName>]"
    echo "Example: ./launch.sh -version v001"
    echo "         ./launch.sh -version v001 -service DiagnosisService"
    exit 1
fi
cd diagnosis
java -cp "btsn.places.Diagnosis.jar:lib/*" org.btsn.handlers.ServiceLoader "$@"
cd ..
if [ $? -ne 0 ]; then
    echo ""
    echo "Application exited with an error."
fi
		