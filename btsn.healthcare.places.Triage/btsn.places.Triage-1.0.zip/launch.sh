#!/bin/bash

echo "Starting Triage Service..."
echo ""
cd triage
java -cp "btsn.healthcare.places.Triage.jar:lib/*" org.btsn.healthcare.handlers.ServiceLoader "$@"
cd ..
if [ $? -ne 0 ]; then
    echo ""
    echo "Application exited with an error."
fi
		