#!/bin/bash

echo "Starting Cardiology Service..."
echo ""
cd cardiology
java -cp "btsn.healthcare.places.Cardiology.jar:lib/*" org.btsn.healthcare.handlers.ServiceLoader "$@"
cd ..
if [ $? -ne 0 ]; then
    echo ""
    echo "Application exited with an error."
fi
		